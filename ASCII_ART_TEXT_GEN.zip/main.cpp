#include <iostream>
#include <opencv2/opencv.hpp>
#include <string>
#include <fstream>

using namespace std ;
//using namespace cv;

void welcomtext(string welcom){
int x = welcom.length();
    for(int i = 0 ; i < x; i++){
    cout << '=';
}
for(int i = 0 ; i < x; i++){
    cout << ' ';
}
for(int i = 0 ; i < x; i++){
    cout << '=';
}
cout << "\n";
for(int i = 0 ; i < x; i++){
    cout << ' ';
}
cout << welcom << "\n";
for(int i = 0 ; i < x; i++){
    cout << '=';
}
for(int i = 0 ; i < x; i++){
    cout << ' ';
    if(i==((x-9)/2)-1){ cout << "Ver. 1.0."; i+=9 ; }
    
}
for(int i = 0 ; i < x; i++){
    cout << '=';
}
}

int main (){



string  welcom = "Wellcom to Image to ASCII converter" ,
        Guide = "\n\n**This program support these PNG, JPEG, JPG, JPE, BMP, DIB, WEBP,\n TIFF, TIF, EXR, JP2, PBM, PGM, PPM, PNM, PXM, SR, RAS, HDR, PIC.\n\n**The maximum resolution support 1,000 x 2,000 pixels.\n\n**Plese enter image path with double backslash(\\) \n\n Example :- D:\\\\image.jpg \n\n **Please enjoy the program :))\n\n" ,
        input_path ,
        input_patht= "Please enter the image path :-  ",
        output_name,
        output_namet = "Please enter a name to save the file(ex:- myimage) :-  ",
        text = "";
welcomtext(welcom);
cout << Guide << "\n" ;

cout << input_patht ;
cin >> input_path ;

//cv::Mat Image= cv::imread("D:\\CPP\\A\\new.jpg");
cv::Mat Image= cv::imread(input_path);


if(Image.empty()){cout << "Image can not read or not detected" << endl ; return -1;}

cout << "\n" << output_namet ;
cin >> output_name ;
//string text ="";
if(output_name.empty()) output_name = "001";
output_name = output_name + ".txt";

ofstream outputtxt(output_name);

string ascii_values = "$@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/\\|()1{}[]?-_+~<>i!lI;:,\"^`'. ";

cv::Mat gray_image , gray_image_resized ;

cv::cvtColor(Image, gray_image,cv::COLOR_BGR2GRAY);

double aspectraio = (double)gray_image.rows / gray_image.cols ;
double s_x = 0.5 ;
double s_y = s_x * aspectraio ;
// cv::Size text_size = cv::getTextSize("M",cv::FONT_HERSHEY_PLAIN,0.5,1, 0);

// double aspect_raio = (double) text_size.width / (text_size.height + 0); 
// double s_y= 0.5;
// double s_x = s_y * aspect_raio ;

cv::resize(gray_image, gray_image_resized,cv::Size(),s_x,s_y,cv::INTER_AREA);

int height = gray_image_resized.rows ;
int width = gray_image_resized.cols ;


for(int i =0 ; i < height ; i++){
    
    for(int j =0; j < width ; j++){
        int pixel_intencity = (int)gray_image_resized.at<uchar>(i,j);
        int index = (pixel_intencity * ascii_values.length() / 255) ;
        string s =  string(1,ascii_values[index]);
        text += s ;
    }
    text += "\n";
}
outputtxt << text  ;
cout << "\n"<< "Your image created. Thanks you." << "\n" << "Your image's text file created on the \"build\" folder."  ;

//cv::waitKey(0);

//std::cout << "Hello, world !" << std::endl ;

return 0;
}
